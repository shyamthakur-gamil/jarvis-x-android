package com.jarvis.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.webkit.WebSettings
import org.json.JSONObject
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

/**
 * Hosts the React/Three.js UI (bundled web assets — see README) inside a
 * WebView, and exposes WebAppBridge as the single, permission-checked path
 * from that UI to real Android functionality.
 */
class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var webView: WebView
    private lateinit var tts: TextToSpeech
    private lateinit var engine: CommandEngine
    private var pendingPermissionRequest: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = (application as JarvisApplication).commandEngine
        tts = TextToSpeech(this, this)
        VoiceListenerService.ensureChannel(this)

        webView = WebView(this)
        setContentView(webView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        webView.addJavascriptInterface(WebAppBridge(this, engine), "AndroidBridge")
        // The built React app (npm run build output of JarvisInterface.jsx)
        // ships in app/src/main/assets/web/ — see README for the build step.
        webView.loadUrl("file:///android_asset/web/index.html")

        intent.getStringExtra(EXTRA_PENDING_CONFIRM)?.let { utterance ->
            CommandParser.parse(utterance)?.let { showConfirmationThenExecute(it) }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) {
            webView.evaluateJavascript("window.refreshJarvis && window.refreshJarvis()", null)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.getStringExtra(EXTRA_EVENT_COMMAND)?.let { cmd ->
            val speech = intent.getStringExtra(EXTRA_EVENT_SPEECH) ?: ""
            val ok = intent.getBooleanExtra(EXTRA_EVENT_OK, false)
            val json = JSONObject().put("type", "command").put("command", cmd).put("ok", ok).put("message", speech).put("speech", speech).toString()
            webView.evaluateJavascript("window.onJarvisEvent && window.onJarvisEvent($json)", null)
            if (speech.isNotBlank()) speak(speech)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.US
    }

    fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utterance")
    }

    /** Native confirmation dialog for sensitive actions — cannot be skipped by the web layer. */
    fun showConfirmationThenExecute(cmd: ParsedCommand) {
        AlertDialog.Builder(this)
            .setTitle("Confirm action")
            .setMessage("Jarvis wants to ${describeForConfirmation(cmd)}. Proceed?")
            .setPositiveButton("Confirm") { _, _ ->
                val outcome = engine.execute(cmd)
                speak(outcome.speech)
                webView.evaluateJavascript("window.onJarvisEvent && window.onJarvisEvent(${jsonOutcome(outcome)})", null)
            }
            .setNegativeButton("Cancel") { _, _ ->
                speak("Okay, cancelled.")
            }
            .setCancelable(true)
            .show()
    }

    private fun describeForConfirmation(cmd: ParsedCommand) = when (cmd.id) {
        "call" -> "call ${cmd.args.getOrElse(0) { "this contact" }}"
        "message" -> "send a message to ${cmd.args.getOrElse(0) { "this contact" }}"
        else -> "run ${cmd.id}"
    }

    private fun jsonOutcome(o: CommandOutcome) =
        "{\"ok\":${o.ok},\"message\":${quote(o.message)},\"speech\":${quote(o.speech)}}"

    private fun quote(s: String) = JSONObject.quote(s)

    /** Routes a permission request from the web UI to the correct native flow. */
    fun requestPermissionFlow(key: String) {
        val manager = PermissionManager(this)
        val info = manager.statusOf(key)
        if (info.settingsOnly) {
            when (key) {
                "accessibility" -> manager.openAccessibilitySettings(this)
                "notification_listener" -> manager.openNotificationListenerSettings(this)
            }
            return
        }
        val permission = info.androidPermission ?: return
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) return
        pendingPermissionRequest = key
        requestPermissions(arrayOf(permission), REQUEST_CODE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            webView.evaluateJavascript(
                "window.onJarvisEvent && window.onJarvisEvent({type:'permission', key:'${pendingPermissionRequest}', granted:$granted})",
                null
            )
            pendingPermissionRequest = null
        }
    }

    fun startJarvisListening() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionFlow("microphone")
            return
        }
        VoiceListenerService.ensureChannel(this)
        val intent = Intent(this, VoiceListenerService::class.java).setAction(VoiceListenerService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
        webView.evaluateJavascript("window.onJarvisEvent && window.onJarvisEvent({type:'state',state:'LISTENING'})", null)
    }

    fun stopJarvisListening() {
        stopService(Intent(this, VoiceListenerService::class.java))
        webView.evaluateJavascript("window.onJarvisEvent && window.onJarvisEvent({type:'state',state:'IDLE'})", null)
    }

    fun handleOutcome(cmd: ParsedCommand, outcome: CommandOutcome) {
        if (outcome.speech.isNotBlank()) speak(outcome.speech)
        val json = JSONObject().put("type", "command").put("command", cmd.id).put("ok", outcome.ok).put("message", outcome.message).put("speech", outcome.speech).apply { outcome.needsPermission?.let { put("needsPermission", it) } }.toString()
        webView.evaluateJavascript("window.onJarvisEvent && window.onJarvisEvent($json)", null)
    }

    override fun onDestroy() {
        tts.stop(); tts.shutdown()
        super.onDestroy()
    }

    companion object {
        const val REQUEST_CODE = 4201
        const val EXTRA_PENDING_CONFIRM = "pending_confirm"
        const val EXTRA_EVENT_COMMAND = "event_command"
        const val EXTRA_EVENT_SPEECH = "event_speech"
        const val EXTRA_EVENT_OK = "event_ok"
    }
}
