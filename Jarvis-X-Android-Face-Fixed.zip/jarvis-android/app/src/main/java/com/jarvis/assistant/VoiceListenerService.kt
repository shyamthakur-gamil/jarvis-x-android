package com.jarvis.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.content.pm.PackageManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat

/**
 * Runs SpeechRecognizer in a loop while the app is in "always listening"
 * mode. ALWAYS shows a persistent foreground notification while the mic is
 * active — there is no hidden/background listening in this app.
 *
 * True hands-free "Hey Jarvis" wake-word detection needs either Android's
 * on-device HotwordDetectionService (API 30+, OEM-dependent) or a
 * third-party wake-word engine (e.g. Porcupine) bundled as a native library.
 * This class provides the hook (`onWakeWordDetected`) where either would
 * plug in; out of the box it falls back to push-to-talk from the UI, which
 * needs no extra library and is fully functional today.
 */
class VoiceListenerService : Service() {

    private lateinit var recognizer: SpeechRecognizer
    private val handler = Handler(Looper.getMainLooper())
    private var listening = false

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification("Idle"))
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return START_NOT_STICKY
        }
        startListeningCycle()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        listening = false
        recognizer.destroy()
        super.onDestroy()
    }

    private fun startListeningCycle() {
        if (listening) return
        listening = true
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        handler.post { recognizer.startListening(intent) }
        updateNotification("Listening")
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: android.os.Bundle) {
            val text = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text != null) handleUtterance(text)
            listening = false
            handler.postDelayed({ startListeningCycle() }, 400) // resume loop
        }
        override fun onError(error: Int) {
            listening = false
            val message = when (error) {
                SpeechRecognizer.ERROR_AUDIO -> "Microphone audio error."
                SpeechRecognizer.ERROR_CLIENT -> "Speech recognizer client error."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
                SpeechRecognizer.ERROR_NETWORK -> "Speech network error."
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech network timeout."
                SpeechRecognizer.ERROR_NO_MATCH -> "I didn't catch that."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer is busy."
                SpeechRecognizer.ERROR_SERVER -> "Speech server error."
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out."
                SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> "Speech service disconnected."
                else -> "Speech recognition error: $error"
            }
            updateNotification(message)
            sendUiEvent("speech_error", message)
            handler.postDelayed({ if (isActive()) startListeningCycle() }, 900)
        }
        override fun onReadyForSpeech(params: android.os.Bundle?) { updateNotification("Listening") }
        override fun onPartialResults(partialResults: android.os.Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { updateNotification("Processing") }
        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
    }

    private fun handleUtterance(text: String) {
        updateNotification("Heard: $text")
        sendUiEvent("heard", text)

        if (!text.contains("jarvis", ignoreCase = true)) {
            handler.postDelayed({ if (isActive()) startListeningCycle() }, 250)
            return
        }

        updateNotification("Processing: $text")
        val engine = (application as JarvisApplication).commandEngine
        val parsed = CommandParser.parse(text)
        if (parsed == null) {
            sendUiEvent("command_error", "I heard: $text, but I don't know that command yet.")
            return
        }
        if (parsed.sensitive) {
            // Sensitive actions are never auto-executed from background listening;
            // hand off to the foreground UI for confirmation.
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(MainActivity.EXTRA_PENDING_CONFIRM, text)
            }
            startActivity(intent)
            return
        }
        val outcome = engine.execute(parsed)
        val main = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_EVENT_COMMAND, parsed.id)
            putExtra(MainActivity.EXTRA_EVENT_SPEECH, outcome.speech)
            putExtra(MainActivity.EXTRA_EVENT_OK, outcome.ok)
        }
        // Bring the HUD forward so the user sees the result, including failures.
        startActivity(main)
    }

    private fun sendUiEvent(type: String, text: String) {
        val main = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_EVENT_COMMAND, type)
            putExtra(MainActivity.EXTRA_EVENT_SPEECH, text)
            putExtra(MainActivity.EXTRA_EVENT_OK, false)
        }
        startActivity(main)
    }

    private fun isActive(): Boolean = !isDestroyed && !isFinishing

    private fun buildNotification(status: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("JARVIS X")
        .setContentText(status)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setOngoing(true)
        .build()

    private fun updateNotification(status: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(status))
    }

    companion object {
        const val CHANNEL_ID = "jarvis_voice"
        const val NOTIF_ID = 1001
        const val ACTION_START = "com.jarvis.assistant.START_LISTENING"
        const val ACTION_STOP = "com.jarvis.assistant.STOP_LISTENING"

        fun ensureChannel(context: android.content.Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(CHANNEL_ID, "Jarvis Voice Status", NotificationManager.IMPORTANCE_LOW)
                context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            }
        }
    }
}
