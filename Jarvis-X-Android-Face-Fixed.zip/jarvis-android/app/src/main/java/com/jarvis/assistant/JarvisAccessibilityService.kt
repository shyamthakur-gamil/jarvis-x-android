package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Opt-in only. The user must manually enable this in
 * Settings > Accessibility > Jarvis Assistant Control — this app never
 * attempts to enable it programmatically, and nothing here runs unless the
 * user has explicitly issued a matching voice command.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* intentionally not logging content */ }
    override fun onInterrupt() {}

    fun performGlobalBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performGlobalHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    /** Finds a visible node whose text/description contains [label] and clicks it. */
    fun clickNodeNamed(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val match = findNode(root, label) ?: return false
        return match.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun findNode(node: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        if (node.text?.contains(label, ignoreCase = true) == true ||
            node.contentDescription?.contains(label, ignoreCase = true) == true) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNode(child, label)?.let { return it }
        }
        return null
    }

    companion object {
        var instance: JarvisAccessibilityService? = null
            private set
    }
}
