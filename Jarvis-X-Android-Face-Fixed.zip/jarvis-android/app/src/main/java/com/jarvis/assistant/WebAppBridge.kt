package com.jarvis.assistant

import android.content.Intent
import android.os.BatteryManager
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject

class WebAppBridge(private val activity: MainActivity, private val engine: CommandEngine) {
    @JavascriptInterface
    fun execute(commandJson: String): String {
        return try {
            val obj = JSONObject(commandJson)
            val id = obj.getString("id")
            val argsArray = obj.optJSONArray("args") ?: JSONArray()
            val args = (0 until argsArray.length()).map { argsArray.getString(it) }
            val parsed = ParsedCommand(id, args, id == "call" || id == "message")
            if (parsed.sensitive) {
                activity.runOnUiThread { activity.showConfirmationThenExecute(parsed) }
                JSONObject().put("ok", true).put("message", "Awaiting confirmation").put("speech", "").toString()
            } else {
                val outcome = engine.execute(parsed)
                activity.runOnUiThread { activity.handleOutcome(parsed, outcome) }
                JSONObject().put("ok", outcome.ok).put("message", outcome.message).put("speech", outcome.speech)
                    .apply { outcome.needsPermission?.let { put("needsPermission", it) } }.toString()
            }
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("message", e.message ?: "error").put("speech", "Something went wrong.").toString()
        }
    }

    @JavascriptInterface
    fun permissionStatuses(): String {
        val arr = JSONArray()
        PermissionManager(activity).allStatuses().forEach {
            arr.put(JSONObject().put("key", it.key).put("name", it.displayName).put("reason", it.reason).put("status", it.status.name))
        }
        return arr.toString()
    }

    @JavascriptInterface fun requestPermission(key: String) = activity.runOnUiThread { activity.requestPermissionFlow(key) }

    @JavascriptInterface
    fun startListening() = activity.runOnUiThread { activity.startJarvisListening() }

    @JavascriptInterface
    fun stopListening() = activity.runOnUiThread { activity.stopJarvisListening() }

    @JavascriptInterface
    fun deviceStatus(): String {
        val bm = activity.getSystemService(BatteryManager::class.java)
        val battery = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val network = (activity.application as JarvisApplication).commandEngine
            .let { DeviceController(activity, PermissionManager(activity)).networkStatus() }
        return JSONObject().put("battery", battery).put("network", network).toString()
    }
}
