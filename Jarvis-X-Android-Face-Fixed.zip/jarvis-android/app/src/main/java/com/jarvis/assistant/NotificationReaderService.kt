package com.jarvis.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class NotificationSnapshot(val appName: String, val title: String, val text: String)

/**
 * Opt-in only via Settings > Notification access. This service does NOT
 * transmit notification content anywhere off-device — it only holds the
 * latest snapshot in memory so CommandEngine can read it aloud when the user
 * explicitly says "read my notifications".
 */
class NotificationReaderService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance == this) instance = null
    }

    fun snapshot(): List<NotificationSnapshot> {
        return try {
            activeNotifications.mapNotNull { sbn: StatusBarNotification ->
                val extras = sbn.notification.extras
                val title = extras.getCharSequence("android.title")?.toString() ?: return@mapNotNull null
                val text = extras.getCharSequence("android.text")?.toString() ?: ""
                NotificationSnapshot(appName = sbn.packageName, title = title, text = text)
            }
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    companion object {
        var instance: NotificationReaderService? = null
            private set
    }
}
