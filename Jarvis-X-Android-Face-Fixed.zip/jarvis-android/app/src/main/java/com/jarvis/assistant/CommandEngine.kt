package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager

/**
 * Parsed voice command handed off by the speech pipeline.
 * `sensitive` mirrors the web UI's confirmation rule so behavior stays
 * consistent whether the command came from the browser demo or on-device.
 */
data class ParsedCommand(val id: String, val args: List<String>, val sensitive: Boolean)

data class CommandOutcome(val ok: Boolean, val message: String, val speech: String, val needsPermission: String? = null)

class CommandEngine(context: Context) {
    private val appContext = context.applicationContext
    private val permissions = PermissionManager(appContext)
    private val device = DeviceController(appContext, permissions)

    /**
     * Executes a command that has ALREADY passed the confirmation step for
     * sensitive actions. The caller (MainActivity / VoiceListenerService) is
     * responsible for asking the user to confirm before calling this for any
     * ParsedCommand where sensitive == true.
     */
    fun execute(cmd: ParsedCommand): CommandOutcome {
        return when (cmd.id) {
            "open_app" -> from(device.openApp(cmd.args.getOrElse(0) { "" }))
            "call" -> placeCall(cmd.args.getOrElse(0) { "" })
            "message" -> sendMessage(cmd.args.getOrElse(0) { "" }, cmd.args.getOrElse(1) { "" })
            "notifications" -> readNotifications()
            "bluetooth" -> from(device.requestBluetoothToggle(cmd.args.getOrElse(0) { "on" } == "on"))
            "flashlight" -> withPermission(Manifest.permission.CAMERA, "camera") {
                from(device.toggleFlashlight(cmd.args.getOrElse(0) { "on" } == "on"))
            }
            "alarm" -> parseAndSetAlarm(cmd.args.getOrElse(0) { "" })
            "reminder" -> CommandOutcome(false, "Reminders are not persisted in this build.", "I can open your calendar or reminder app, but persistent reminders are not wired into this build yet.")
            "battery" -> CommandOutcome(true, "Battery ${device.batteryPercent()}%", "Battery is at ${device.batteryPercent()} percent${if (device.isCharging()) ", and charging" else ""}.")
            "volume" -> from(device.adjustVolume(cmd.args.getOrElse(0) { "increase" }.let { it == "increase" || it == "raise" }))
            "brightness" -> from(device.adjustBrightness(cmd.args.getOrElse(0) { "increase" }.let { it == "increase" || it == "brighten" }))
            "photo" -> withPermission(Manifest.permission.CAMERA, "camera") { from(device.openCamera(video = false)) }
            "record" -> withPermission(Manifest.permission.CAMERA, "camera") { from(device.openCamera(video = true)) }
            "navigate" -> withPermission(Manifest.permission.ACCESS_FINE_LOCATION, "location") { from(device.navigateTo(cmd.args.getOrElse(0) { "" })) }
            "music_play" -> from(device.mediaControl(play = true))
            "music_pause" -> from(device.mediaControl(play = false))
            "time" -> CommandOutcome(true, "Time reported.", "It's " + java.text.SimpleDateFormat("h:mm a").format(java.util.Date()) + ".")
            "weather" -> CommandOutcome(false, "Weather provider is not configured.", "Weather needs a live weather provider in this build, so I won't pretend I have current weather data.")
            "camera_open" -> from(device.openApp("camera"))
            "back" -> JarvisAccessibilityService.instance?.performGlobalBack()
                ?.let { CommandOutcome(true, "Back performed.", "Going back.") }
                ?: CommandOutcome(false, "Accessibility service not enabled.", "I need Accessibility access enabled to do that — check the Permissions tab.")
            "home" -> JarvisAccessibilityService.instance?.performGlobalHome()
                ?.let { CommandOutcome(true, "Home performed.", "Going home.") }
                ?: CommandOutcome(false, "Accessibility service not enabled.", "I need Accessibility access enabled to do that — check the Permissions tab.")
            else -> CommandOutcome(false, "Unrecognized command id: ${cmd.id}", "I'm not sure how to do that yet.")
        }
    }

    private fun from(r: ActionResult) = CommandOutcome(r.ok, r.message, r.speech)

    private fun withPermission(permission: String, key: String, action: () -> CommandOutcome): CommandOutcome {
        val granted = ContextCompat.checkSelfPermission(appContext, permission) == PackageManager.PERMISSION_GRANTED
        return if (granted) action()
        else CommandOutcome(false, "Missing permission: $permission", "I need $key permission for that — check the Permissions tab to grant it.", needsPermission = key)
    }

    private fun placeCall(name: String): CommandOutcome {
        val granted = ContextCompat.checkSelfPermission(appContext, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val hasContacts = ContextCompat.checkSelfPermission(appContext, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        if (!hasContacts) return CommandOutcome(false, "Missing contacts permission.", "I need Contacts permission to find $name — check the Permissions tab.", needsPermission = "contacts")
        val number = resolveContactNumber(name)
            ?: return CommandOutcome(false, "No contact matched \"$name\".", "I couldn't find a contact named $name.")
        val uri = Uri.parse("tel:$number")
        return if (granted) {
            appContext.startActivity(Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            CommandOutcome(true, "Calling $name ($number).", "Calling $name.")
        } else {
            // Fall back to the dialer, which needs no dangerous permission, rather
            // than silently failing.
            appContext.startActivity(Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            CommandOutcome(false, "No CALL_PHONE permission — opened dialer instead.", "I don't have permission to call directly, so I've opened the dialer with $name's number.", needsPermission = "phone")
        }
    }

    private fun sendMessage(name: String, body: String): CommandOutcome {
        val granted = ContextCompat.checkSelfPermission(appContext, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
        val hasContacts = ContextCompat.checkSelfPermission(appContext, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        if (!hasContacts) return CommandOutcome(false, "Missing contacts permission.", "I need Contacts permission to find $name — check the Permissions tab.", needsPermission = "contacts")
        val number = resolveContactNumber(name)
            ?: return CommandOutcome(false, "No contact matched \"$name\".", "I couldn't find a contact named $name.")
        if (!granted) return CommandOutcome(false, "Missing SMS permission.", "I need SMS permission to text $name — check the Permissions tab.", needsPermission = "sms")
        return try {
            val sms = appContext.getSystemService(SmsManager::class.java)
            sms.sendTextMessage(number, null, body.ifBlank { "Hello from Jarvis" }, null, null)
            CommandOutcome(true, "Message sent to $name.", "Message sent to $name.")
        } catch (e: Exception) {
            CommandOutcome(false, "SMS send failed: ${e.message}", "Something went wrong sending that message.")
        }
    }

    private fun readNotifications(): CommandOutcome {
        val active = NotificationReaderService.instance?.snapshot()
        return if (active == null) {
            CommandOutcome(false, "Notification Listener not enabled.", "I need Notification access enabled to read those — check the Permissions tab.", needsPermission = "notification_listener")
        } else if (active.isEmpty()) {
            CommandOutcome(true, "No active notifications.", "You have no new notifications.")
        } else {
            val summary = active.take(3).joinToString(". ") { "${it.appName}: ${it.title}" }
            CommandOutcome(true, "Read ${active.size} notifications.", summary)
        }
    }

    private fun parseAndSetAlarm(timeText: String): CommandOutcome {
        // Very small natural-language time parser: "7 AM", "7:30 pm", "19:00"
        val regex = Regex("""(\d{1,2})(?::(\d{2}))?\s*(am|pm)?""", RegexOption.IGNORE_CASE)
        val m = regex.find(timeText) ?: return CommandOutcome(false, "Couldn't parse time: $timeText", "I couldn't understand that time.")
        var hour = m.groupValues[1].toInt()
        val minute = m.groupValues[2].ifEmpty { "0" }.toInt()
        val meridiem = m.groupValues[3].lowercase()
        if (meridiem == "pm" && hour < 12) hour += 12
        if (meridiem == "am" && hour == 12) hour = 0
        return from(device.setAlarm(hour, minute))
    }

    private fun resolveContactNumber(name: String): String? {
        val resolver = appContext.contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        ) ?: return null
        cursor.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return it.getString(idx)
            }
        }
        return null
    }
}
