package com.jarvis.assistant

import android.app.AlarmManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat

/**
 * Result of any device action. `ok=false` always comes with a human-readable
 * `message` explaining WHY — Jarvis never silently pretends success.
 */
data class ActionResult(val ok: Boolean, val message: String, val speech: String)

class DeviceController(private val context: Context, private val permissions: PermissionManager) {

    // ---- Queries (no dangerous permission required) ------------------------

    fun batteryPercent(): Int {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    fun isCharging(): Boolean {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.isCharging
    }

    fun networkStatus(): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "Offline"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            else -> "Connected"
        }
    }

    // ---- Actions -------------------------------------------------------------

    fun toggleFlashlight(turnOn: Boolean): ActionResult {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull {
                cameraManager.getCameraCharacteristics(it)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return ActionResult(false, "No flash-equipped camera found on this device.", "This device doesn't have a flashlight.")
            cameraManager.setTorchMode(cameraId, turnOn)
            ActionResult(true, "Flashlight ${if (turnOn) "on" else "off"}.", "Flashlight is ${if (turnOn) "on" else "off"}.")
        } catch (e: Exception) {
            ActionResult(false, "Camera busy or unavailable: ${e.message}", "I couldn't reach the flashlight right now.")
        }
    }

    /**
     * Bluetooth: on Android 13+ there is NO way to silently toggle Bluetooth
     * for a third-party app — Google requires the system panel. We open that
     * panel rather than pretend we flipped a switch that doesn't exist.
     */
    fun requestBluetoothToggle(turnOn: Boolean): ActionResult {
        val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return ActionResult(
            true,
            "Opened Bluetooth settings — modern Android requires manual confirmation here.",
            "I've opened Bluetooth settings for you — Android doesn't allow apps to switch it silently anymore."
        )
    }

    fun setAlarm(hour: Int, minute: Int, label: String = "JARVIS X alarm"): ActionResult {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            ActionResult(true, "Alarm requested for $hour:$minute.", "Alarm set for ${String.format("%02d:%02d", hour, minute)}.")
        } else {
            ActionResult(false, "No clock app available to handle alarm intent.", "I couldn't find a clock app to set that alarm.")
        }
    }

    fun adjustVolume(increase: Boolean): ActionResult {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (increase) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        return ActionResult(true, "Volume adjusted.", "Volume ${if (increase) "increased" else "decreased"}.")
    }

    /**
     * WRITE_SETTINGS (needed to change screen brightness programmatically) is a
     * "special app access" permission Android will not grant via a normal
     * runtime dialog — it requires the user to flip it on in a dedicated
     * settings screen. We check for it and guide the user there instead of
     * silently failing or pretending it worked.
     */
    fun adjustBrightness(increase: Boolean): ActionResult {
        if (!Settings.System.canWrite(context)) {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return ActionResult(false, "Missing WRITE_SETTINGS permission.", "I need one-time permission to modify system settings — I've opened that screen for you.")
        }
        val current = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        val next = (current + if (increase) 40 else -40).coerceIn(10, 255)
        Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, next)
        return ActionResult(true, "Brightness set to $next/255.", "Brightness ${if (increase) "increased" else "decreased"}.")
    }

    fun openApp(packageHint: String): ActionResult {
        val pkg = KNOWN_PACKAGES[packageHint.lowercase()]
        val launchIntent = pkg?.let { context.packageManager.getLaunchIntentForPackage(it) }
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            ActionResult(true, "Launched $packageHint.", "Opening $packageHint.")
        } else {
            ActionResult(false, "$packageHint is not installed or not recognized.", "I couldn't find $packageHint installed on this device.")
        }
    }

    fun openCamera(video: Boolean): ActionResult {
        val action = if (video) MediaStore.ACTION_VIDEO_CAPTURE else MediaStore.ACTION_IMAGE_CAPTURE
        val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            ActionResult(true, "Camera opened.", if (video) "Recording started." else "Taking a photo.")
        } else {
            ActionResult(false, "No camera app available.", "I couldn't find a camera app to use.")
        }
    }

    fun navigateTo(destination: String): ActionResult {
        val uri = Uri.parse("geo:0,0?q=${Uri.encode(destination)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            ActionResult(true, "Navigation started to $destination.", "Navigating to $destination.")
        } else {
            ActionResult(false, "No maps app available.", "I couldn't find a maps app installed.")
        }
    }

    fun mediaControl(play: Boolean): ActionResult {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val keyCode = if (play) android.view.KeyEvent.KEYCODE_MEDIA_PLAY else android.view.KeyEvent.KEYCODE_MEDIA_PAUSE
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode))
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode))
        return ActionResult(true, "Media key sent.", if (play) "Playing music." else "Music paused.")
    }

    companion object {
        private val KNOWN_PACKAGES = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "camera" to "com.android.camera",
            "maps" to "com.google.android.apps.maps",
            "spotify" to "com.spotify.music",
            "gmail" to "com.google.android.gm",
            "chrome" to "com.android.chrome",
        )
    }
}
