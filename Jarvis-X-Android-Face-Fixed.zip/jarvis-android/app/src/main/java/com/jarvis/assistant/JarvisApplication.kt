package com.jarvis.assistant

import android.app.Application

class JarvisApplication : Application() {
    lateinit var commandEngine: CommandEngine
        private set

    override fun onCreate() {
        super.onCreate()
        commandEngine = CommandEngine(this)
    }
}
