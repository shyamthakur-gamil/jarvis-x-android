package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Single source of truth for "can Jarvis actually do this right now".
 * The web UI's Permission Center reflects exactly what this class reports —
 * nothing is faked as granted, and nothing is auto-requested without the
 * user having triggered a matching voice command first.
 */
data class PermissionInfo(
    val key: String,
    val displayName: String,
    val reason: String,
    val androidPermission: String?, // null for permissions that aren't runtime-grantable (accessibility, notif listener)
    val status: PermissionStatus,
    val settingsOnly: Boolean = false
)

enum class PermissionStatus { GRANTED, DENIED, NOT_REQUESTED, REQUIRES_SETTINGS }

class PermissionManager(private val context: Context) {

    private val runtimePermissions = mapOf(
        "microphone" to Triple(Manifest.permission.RECORD_AUDIO, "Microphone", "Required to hear wake word and voice commands."),
        "camera" to Triple(Manifest.permission.CAMERA, "Camera", "Needed for \"take a photo\" / \"start recording\"."),
        "contacts" to Triple(Manifest.permission.READ_CONTACTS, "Contacts", "Needed to resolve names like \"Mom\" to a phone number."),
        "phone" to Triple(Manifest.permission.CALL_PHONE, "Phone", "Needed to place calls on your behalf."),
        "sms" to Triple(Manifest.permission.SEND_SMS, "SMS", "Needed to send text messages you dictate."),
        "location" to Triple(Manifest.permission.ACCESS_FINE_LOCATION, "Location", "Needed for navigation and weather requests."),
        "notifications_post" to Triple(
            if (Build.VERSION.SDK_INT >= 33) Manifest.permission.POST_NOTIFICATIONS else "",
            "Notifications", "Lets Jarvis show its own status notifications."
        ),
        "bluetooth" to Triple(
            if (Build.VERSION.SDK_INT >= 31) Manifest.permission.BLUETOOTH_CONNECT else "",
            "Bluetooth", "Needed to toggle Bluetooth on supported Android versions."
        ),
    )

    fun statusOf(key: String): PermissionInfo {
        // Settings-only special cases
        if (key == "accessibility") {
            return PermissionInfo(key, "Accessibility Service",
                "Optional — lets Jarvis tap, scroll, and navigate on your behalf inside supported apps.",
                null, if (isAccessibilityServiceEnabled()) PermissionStatus.GRANTED else PermissionStatus.REQUIRES_SETTINGS, settingsOnly = true)
        }
        if (key == "notification_listener") {
            return PermissionInfo(key, "Notification Listener",
                "Optional — lets Jarvis read the content of your notifications aloud.",
                null, if (isNotificationListenerEnabled()) PermissionStatus.GRANTED else PermissionStatus.REQUIRES_SETTINGS, settingsOnly = true)
        }

        val entry = runtimePermissions[key] ?: return PermissionInfo(key, key, "Unknown permission", null, PermissionStatus.NOT_REQUESTED)
        val (perm, name, reason) = entry
        if (perm.isEmpty()) {
            // Not applicable on this OS version -> treat as granted (nothing to ask for)
            return PermissionInfo(key, name, reason, null, PermissionStatus.GRANTED)
        }
        val granted = ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
        return PermissionInfo(key, name, reason, perm, if (granted) PermissionStatus.GRANTED else PermissionStatus.NOT_REQUESTED)
    }

    fun allStatuses(): List<PermissionInfo> =
        runtimePermissions.keys.map { statusOf(it) } + statusOf("accessibility") + statusOf("notification_listener")

    /** Request a single runtime permission. Must be called from an Activity, one permission at a time. */
    fun requestRuntimePermission(activity: Activity, key: String, requestCode: Int) {
        val info = statusOf(key)
        val perm = info.androidPermission ?: return // settings-only permission, nothing to request here
        ActivityCompat.requestPermissions(activity, arrayOf(perm), requestCode)
    }

    fun openAppSettings(activity: Activity) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${activity.packageName}"))
        activity.startActivity(intent)
    }

    fun openAccessibilitySettings(activity: Activity) {
        activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    fun openNotificationListenerSettings(activity: Activity) {
        activity.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "${context.packageName}/${JarvisAccessibilityService::class.java.canonicalName}"
        val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return enabled.split(":").any { it.equals(expected, ignoreCase = true) }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: ""
        return enabled.contains(context.packageName)
    }
}
