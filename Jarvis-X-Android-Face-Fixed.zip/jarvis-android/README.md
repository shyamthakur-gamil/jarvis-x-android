# JARVIS X — Android

A native Android JARVIS X-style voice assistant with a futuristic WebView HUD and explicit Android permission handling.

## Build on a computer

1. Open the `jarvis-android` folder in Android Studio.
2. Allow Gradle sync and install Android SDK 34 if prompted.
3. Build > Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Build without a PC (GitHub Actions)

This repository includes `.github/workflows/build-apk.yml`. Upload the project to a GitHub repository, then open **Actions → Build JARVIS X APK → Run workflow**. After the workflow finishes, download the `jarvis-debug-apk` artifact and extract `app-debug.apk`.

## What works

- Futuristic animated HUD with JARVIS X boot sequence.
- Native Android voice recognition + text-to-speech.
- Real battery/network status.
- App launching for supported apps.
- Flashlight, camera intents, alarms, volume, media, navigation.
- Optional calls/SMS with confirmation.
- Optional Accessibility Service for global Back/Home and supported UI actions.
- Optional Notification Listener for reading active notifications.
- Permission Center.

## Android limitations

A normal Android app cannot obtain unrestricted system control. Some actions require Settings, user confirmation, Accessibility/Notification Access, or may be restricted by the device manufacturer. The app never attempts to bypass Android security.

The hands-free `Hey Jarvis` mode uses Android SpeechRecognizer in a foreground service. This is not the same as a hardware-level low-power wake-word engine; behavior varies by Android version and manufacturer.
