package com.jarvis.assistant

/**
 * Lightweight natural-language rule matcher. Deliberately simple (regex, not
 * an on-device LLM) so behavior is predictable and auditable — swap in an
 * on-device model later if you need to handle more open-ended phrasing like
 * "can you make the screen brighter?".
 */
object CommandParser {

    private data class Rule(val id: String, val regex: Regex, val sensitive: Boolean)

    private val rules = listOf(
        Rule("open_app", Regex("""open (youtube|whatsapp|camera|maps|spotify|gmail|chrome)""", RegexOption.IGNORE_CASE), false),
        Rule("call", Regex("""call (.+)""", RegexOption.IGNORE_CASE), true),
        Rule("message", Regex("""(?:send a message to|message|text) (.+?)(?: saying (.+))?$""", RegexOption.IGNORE_CASE), true),
        Rule("notifications", Regex("""read (?:my )?notifications""", RegexOption.IGNORE_CASE), false),
        Rule("bluetooth", Regex("""turn (on|off) bluetooth""", RegexOption.IGNORE_CASE), false),
        Rule("flashlight", Regex("""turn (on|off) (?:the )?flashlight""", RegexOption.IGNORE_CASE), false),
        Rule("alarm", Regex("""set an? alarm for (.+)""", RegexOption.IGNORE_CASE), false),
        Rule("reminder", Regex("""set an? reminder(?: to (.+))?""", RegexOption.IGNORE_CASE), false),
        Rule("battery", Regex("""(?:what(?:'s| is) my )?battery(?: percentage)?""", RegexOption.IGNORE_CASE), false),
        Rule("volume", Regex("""(increase|decrease|lower|raise) (?:the )?volume""", RegexOption.IGNORE_CASE), false),
        Rule("brightness", Regex(""".*(increase|decrease|dim|brighten).*(brightness|screen)""", RegexOption.IGNORE_CASE), false),
        Rule("photo", Regex("""take a photo|take a picture""", RegexOption.IGNORE_CASE), false),
        Rule("record", Regex("""start recording""", RegexOption.IGNORE_CASE), false),
        Rule("navigate", Regex("""navigate to (.+)""", RegexOption.IGNORE_CASE), false),
        Rule("music_play", Regex("""play music""", RegexOption.IGNORE_CASE), false),
        Rule("music_pause", Regex("""pause music""", RegexOption.IGNORE_CASE), false),
        Rule("time", Regex("""what time is it""", RegexOption.IGNORE_CASE), false),
        Rule("weather", Regex("""what(?:'s| is) the weather""", RegexOption.IGNORE_CASE), false),
        Rule("camera_open", Regex("""open camera""", RegexOption.IGNORE_CASE), false),
        Rule("back", Regex("""go back""", RegexOption.IGNORE_CASE), false),
        Rule("home", Regex("""(go to )?home screen""", RegexOption.IGNORE_CASE), false),
    )

    fun parse(rawText: String): ParsedCommand? {
        val text = rawText.trim().replace(Regex("""^hey jarvis,?\s*""", RegexOption.IGNORE_CASE), "")
        for (rule in rules) {
            val match = rule.regex.find(text) ?: continue
            val args = match.groupValues.drop(1).filter { it.isNotBlank() }
            return ParsedCommand(rule.id, args, rule.sensitive)
        }
        return null
    }
}
